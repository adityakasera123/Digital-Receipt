import AnalyticsHeader from '../../components/analytics/AnalyticsHeader';
import AnalyticsSummaryGrid from '../../components/analytics/AnalyticsSummaryGrid';
import MonthlyExpenseChart from '../../components/analytics/MonthlyExpenseChart';
import CategorySpending from '../../components/analytics/CategorySpending';
import QuickInsights from '../../components/analytics/QuickInsights';
import RecentActivity from '../../components/analytics/RecentActivity';
import AnalyticsSkeleton from '../../components/analytics/AnalyticsSkeleton';
import StoreSpending from '../../components/analytics/StoreSpending';
import MonthlyComparison from '../../components/analytics/MonthlyComparison';
import SpendingTrend from '../../components/analytics/SpendingTrend';
import SpendingInsights from '../../components/analytics/SpendingInsights';

import useAnalytics from '../../hooks/useAnalytics';

const Analytics = () => {
  const { loading, analytics } = useAnalytics();

  if (loading) {
    return <AnalyticsSkeleton />;
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <AnalyticsHeader />

      {/* Summary Cards */}
      <AnalyticsSummaryGrid analytics={analytics} />

      {/* Charts */}
      <div className="mt-8 grid grid-cols-1 gap-8 xl:grid-cols-3">
        <div className="xl:col-span-2">
          <MonthlyExpenseChart data={analytics.monthlyExpenses} />
        </div>

        <div>
          <CategorySpending categories={analytics.categorySpending} />
        </div>
      </div>

      <StoreSpending stores={analytics.storeSpending} />

      {/* Monthly Comparison */}
<MonthlyComparison
  comparison={analytics.monthlyComparison}
/>

<SpendingTrend
  trend={analytics.spendingTrend}
/>

      {/* Quick Insights */}
      <QuickInsights analytics={analytics} />

      {/* Spending Insights */}
<SpendingInsights
  insights={analytics.spendingInsights}
/>

      {/* Recent Activity */}
      <RecentActivity receipts={analytics.receipts} />
    </div>
  );
};

export default Analytics;